package com.example.petcare;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class PrepoznavanjeSimptomaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prepoznavanjesimptoma_activity);

    }
}
