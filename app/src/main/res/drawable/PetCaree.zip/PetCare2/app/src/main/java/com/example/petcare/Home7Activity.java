package com.example.petcare;


import androidx.appcompat.app.AppCompatActivity;

public class Home7Activity extends AppCompatActivity {


}